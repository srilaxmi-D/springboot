package com.sri.employee.empolyeedemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmpolyeedemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmpolyeedemoApplication.class, args);
		System.out.println("Aruna");
	}

}
