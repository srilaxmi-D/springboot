package com.sri.employee.empolyeedemo.service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.sri.employee.empolyeedemo.Entity.EmployeeEntity;
import com.sri.employee.empolyeedemo.dao.EmployeeDao;
import com.sri.employee.empolyeedemo.bean.Employee;
@Service
public class EmployeeService {

	@Autowired
	private EmployeeDao employeeDAO;

	 // name element defines name of the cache used.
	 // key defines the index value for the cached object.
	 // This annotation makes sure that the return value from
	 // this method is stored in the cache empCacheSpace with the employeeId as the key
     // and return values as the value.
	 // Note: employeeId is retrieved from the parameter
	@Cacheable(value="empCacheSpace", key="#employeeId")
	public Employee getEmployeeDetailByEmployeeId(int employeeId){
		Employee employee =null;
		Optional<EmployeeEntity> employeeEntity= employeeDAO.findById(employeeId);
		if(employeeEntity!=null){
			employee= new Employee();
			BeanUtils.copyProperties(employeeEntity, employee);
		}
		return employee;
	}
	
	// Return value is saved in the cache with random key
	@Cacheable(value="empCacheSpace")
	public Collection<Employee> getEmployeeDetails(){
		Collection<EmployeeEntity> collec =employeeDAO.findAll();
		List<Employee> listEmployee = new ArrayList<Employee> ();
		for (EmployeeEntity employeeEntity : collec) {
			Employee employee=new Employee();
			BeanUtils.copyProperties(employeeEntity, employee);
			listEmployee.add(employee);
		}
		return listEmployee;
	}

	//2nd to discuss
	// @CachePut is used to put the items in the cache
	// or update the items already in the cache.
	// This annotation makes sure that the return value from
	// this method is stored in the cache empCacheSpace with the employeeId as the key
    // and return values as the Employee object returned by the method after the DB update
	// Note: key is derived from the method's return value,
	// if return type of method would have been int 
	// then it would have format: result
	@CachePut(value="empCacheSpace",key="#result.employeeId") 
	public Employee addEmployee(Employee employee) {

		EmployeeEntity employeeEntity = new EmployeeEntity();
		BeanUtils.copyProperties(employee, employeeEntity);
		EmployeeEntity emp= (EmployeeEntity)employeeDAO.save(employeeEntity);
		System.out.println(emp);
		Employee employee2 = new Employee();
		
		BeanUtils.copyProperties(emp,employee2 );
		return employee2;
	}	
	
	


	}
	
	



