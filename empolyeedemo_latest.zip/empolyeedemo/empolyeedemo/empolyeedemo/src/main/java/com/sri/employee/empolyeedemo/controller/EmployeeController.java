package com.sri.employee.empolyeedemo.controller;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.sri.employee.empolyeedemo.service.EmployeeService;
import com.sri.employee.empolyeedemo.Entity.EmployeeEntity;
import com.sri.employee.empolyeedemo.bean.Employee;

@RestController
public class EmployeeController {
	
	@Autowired
	private EmployeeService employeeService;

	
	@RequestMapping(value="emp/controller/getDetails",method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Collection<Employee>> getEmployeeDetails(){
		Collection <Employee> listEmployee = employeeService.getEmployeeDetails();
		System.out.println(listEmployee);
		return new ResponseEntity<Collection<Employee>>(listEmployee, HttpStatus.OK);
	}
	
	@RequestMapping(value="emp/controller/getDetailsById/{id}",method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Employee> getEmployeeDetailByEmployeeId(@PathVariable("id") int myId){
		Employee employee = employeeService.getEmployeeDetailByEmployeeId(myId);
		
		if(employee!=null)
		{
			return new ResponseEntity<Employee>(employee,HttpStatus.OK);
		}
		else
		{
			return new ResponseEntity<Employee>(HttpStatus.NOT_FOUND);
		}
	}
		
		
	@RequestMapping(value="/emp/controller/addEmp",
			method=RequestMethod.POST,
			consumes=MediaType.APPLICATION_JSON_VALUE,
			produces=MediaType.TEXT_HTML_VALUE)
	public ResponseEntity<String> addEmployee(@RequestBody Employee employee){
		Employee employee2= employeeService.addEmployee(employee);
		System.out.println("[id]:"+employee2.getEmployeeId());
		return new ResponseEntity<String>("Employee added successfully with id:"+employee2.getEmployeeId(),HttpStatus.CREATED);
	}
	


}
