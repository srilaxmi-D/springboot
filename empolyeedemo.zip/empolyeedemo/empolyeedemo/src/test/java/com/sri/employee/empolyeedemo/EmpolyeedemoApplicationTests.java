package com.sri.employee.empolyeedemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmpolyeedemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
