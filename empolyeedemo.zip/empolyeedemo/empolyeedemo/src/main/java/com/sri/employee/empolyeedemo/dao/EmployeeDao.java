package com.sri.employee.empolyeedemo.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sri.employee.empolyeedemo.Entity.EmployeeEntity;

public interface EmployeeDao extends JpaRepository<EmployeeEntity, Integer>  {
	

	}



